# Dự án sinh viên nghiên cứu khoa học trường Đại học Sư phạm kỹ thuật Đà Nẵng 2022
- Url connect data: /connect/data.php
- File kết nối mysql: /connect/config.php
- Trang admin: url: /admin => Username: admin | Password: admin
#### php
